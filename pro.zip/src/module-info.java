/**
 * 
 */
/**
 * @author Asus
 *
 */
module stockHnosMorales {
}